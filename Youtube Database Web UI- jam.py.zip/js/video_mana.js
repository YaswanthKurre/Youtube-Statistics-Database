(function($, task) {
"use strict";

function Events1() { // video_mana 

	function on_page_loaded(task) {
		
		$("title").text(task.item_caption);
		$("#title").text(task.item_caption);
		  
		if (task.safe_mode) {
			$("#user-info").text(task.user_info.role_name + ' ' + task.user_info.user_name);
			$('#log-out')
			.show() 
			.click(function(e) {
				e.preventDefault();
				task.logout();
			}); 
		}
	
		if (task.full_width) {
			$('#container').removeClass('container').addClass('container-fluid');
		}
		$('#container').show();
		
		task.create_menu($("#menu"), $("#content"), {
			// splash_screen: '<h1 class="text-center">Application</h1>',
			view_first: true
		});
	
		// $(document).ajaxStart(function() { $("html").addClass("wait"); });
		// $(document).ajaxStop(function() { $("html").removeClass("wait"); });
	} 
	
	function on_view_form_created(item) {
		var table_options_height = item.table_options.height,
			table_container;
	
		item.clear_filters();
		
		item.view_options.table_container_class = 'view-table';
		item.view_options.detail_container_class = 'view-detail';
		item.view_options.open_item = true;
		
		if (item.view_form.hasClass('modal')) {
			item.view_options.width = 1060;
			item.table_options.height = $(window).height() - 300;
		}
		else {
			if (!item.table_options.height) {
				item.table_options.height = $(window).height() - $('body').height() - 20;
			}
		}
		
		if (item.can_create()) {
			item.view_form.find("#new-btn").on('click.task', function(e) {
				e.preventDefault();
				if (item.master) {
					item.append_record();
				}
				else {
					item.insert_record();
				}
			});
		}
		else {
			item.view_form.find("#new-btn").prop("disabled", true);
		}
	
		item.view_form.find("#edit-btn").on('click.task', function(e) {
			e.preventDefault();
			item.edit_record();
		});
	
		if (item.can_delete()) {
			item.view_form.find("#delete-btn").on('click.task', function(e) {
				e.preventDefault();
				item.delete_record();
			});
		}
		else {
			item.view_form.find("#delete-btn").prop("disabled", true);
		}
		
		create_print_btns(item);
	
		task.view_form_created(item);
		
		if (!item.master && item.owner.on_view_form_created) {
			item.owner.on_view_form_created(item);
		}
	
		if (item.on_view_form_created) {
			item.on_view_form_created(item);
		}
		
		item.create_view_tables();
		
		if (!item.master && item.view_options.open_item) {
			item.open(true);
		}
	
		if (!table_options_height) {
			item.table_options.height = undefined;
		}
		return true;
	}
	
	function on_view_form_shown(item) {
		item.view_form.find('.dbtable.' + item.item_name + ' .inner-table').focus();
	}
	
	function on_view_form_closed(item) {
		if (!item.master && item.view_options.open_item) {	
			item.close();
		}
	}
	
	function on_edit_form_created(item) {
		item.edit_options.inputs_container_class = 'edit-body';
		item.edit_options.detail_container_class = 'edit-detail';
		
		item.edit_form.find("#cancel-btn").on('click.task', function(e) { item.cancel_edit(e) });
		item.edit_form.find("#ok-btn").on('click.task', function() { item.apply_record() });
		if (!item.is_new() && !item.can_modify) {
			item.edit_form.find("#ok-btn").prop("disabled", true);
		}
		
		task.edit_form_created(item);
		
		if (!item.master && item.owner.on_edit_form_created) {
			item.owner.on_edit_form_created(item);
		}
	
		if (item.on_edit_form_created) {
			item.on_edit_form_created(item);
		}
			
		item.create_inputs(item.edit_form.find('.' + item.edit_options.inputs_container_class));
		item.create_detail_views(item.edit_form.find('.' + item.edit_options.detail_container_class));
	
		return true;
	}
	
	function on_edit_form_close_query(item) {
		var result = true;
		if (item.is_changing()) {
			if (item.is_modified()) {
				item.yes_no_cancel(task.language.save_changes,
					function() {
						item.apply_record();
					},
					function() {
						item.cancel_edit();
					}
				);
				result = false;
			}
			else {
				item.cancel_edit();
			}
		}
		return result;
	}
	
	function on_filter_form_created(item) {
		item.filter_options.title = item.item_caption + ' - filters';
		item.create_filter_inputs(item.filter_form.find(".edit-body"));
		item.filter_form.find("#cancel-btn").on('click.task', function() {
			item.close_filter_form(); 
		});
		item.filter_form.find("#ok-btn").on('click.task', function() { 
			item.set_order_by(item.view_options.default_order);
			item.apply_filters(item._search_params); 
		});
	}
	
	function on_param_form_created(item) {
		item.create_param_inputs(item.param_form.find(".edit-body"));
		item.param_form.find("#cancel-btn").on('click.task', function() { 
			item.close_param_form();
		});
		item.param_form.find("#ok-btn").on('click.task', function() { 
			item.process_report();
		});
	}
	
	function on_before_print_report(report) {
		var select;
		report.extension = 'pdf';
		if (report.param_form) {
			select = report.param_form.find('select');
			if (select && select.val()) {
				report.extension = select.val();
			}
		}
	}
	
	function on_view_form_keyup(item, event) {
		if (event.keyCode === 45 && event.ctrlKey === true){
			if (item.master) {
				item.append_record();
			}
			else {
				item.insert_record();				
			}
		}
		else if (event.keyCode === 46 && event.ctrlKey === true){
			item.delete_record(); 
		}
	}
	
	function on_edit_form_keyup(item, event) {
		if (event.keyCode === 13 && event.ctrlKey === true){
			item.edit_form.find("#ok-btn").focus(); 
			item.apply_record();
		}
	}
	
	function create_print_btns(item) {
		var i,
			$ul,
			$li,
			reports = [];
		if (item.reports) {
			for (i = 0; i < item.reports.length; i++) {
				if (item.reports[i].can_view()) {
					reports.push(item.reports[i]);
				}
			}
			if (reports.length) {
				$ul = item.view_form.find("#report-btn ul");
				for (i = 0; i < reports.length; i++) {
					$li = $('<li><a href="#">' + reports[i].item_caption + '</a></li>');
					$li.find('a').data('report', reports[i]);
					$li.on('click', 'a', function(e) {
						e.preventDefault();
						$(this).data('report').print(false);
					});
					$ul.append($li);
				}
			}
			else {
				item.view_form.find("#report-btn").hide();
			}
		}
		else {
			item.view_form.find("#report-btn").hide();
		}
	}
	this.on_page_loaded = on_page_loaded;
	this.on_view_form_created = on_view_form_created;
	this.on_view_form_shown = on_view_form_shown;
	this.on_view_form_closed = on_view_form_closed;
	this.on_edit_form_created = on_edit_form_created;
	this.on_edit_form_close_query = on_edit_form_close_query;
	this.on_filter_form_created = on_filter_form_created;
	this.on_param_form_created = on_param_form_created;
	this.on_before_print_report = on_before_print_report;
	this.on_view_form_keyup = on_view_form_keyup;
	this.on_edit_form_keyup = on_edit_form_keyup;
	this.create_print_btns = create_print_btns;
}

task.events.events1 = new Events1();

function Events9() { // video_mana.data.category 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events9 = new Events9();

function Events10() { // video_mana.data.channel 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events10 = new Events10();

function Events11() { // video_mana.data.comments 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events11 = new Events11();

function Events12() { // video_mana.data.country 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events12 = new Events12();

function Events13() { // video_mana.data.owners 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events13 = new Events13();

function Events14() { // video_mana.data.playlist 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events14 = new Events14();

function Events15() { // video_mana.data.tag 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events15 = new Events15();

function Events16() { // video_mana.data.video 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events16 = new Events16();

function Events17() { // video_mana.data.videoproperties 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events17 = new Events17();

function Events18() { // video_mana.data.video_contains_tags 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events18 = new Events18();

function Events19() { // video_mana.data.video_in_playlist 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events19 = new Events19();

function Events20() { // video_mana.data.video_trends_at 

	function on_view_form_created(item) {
		item.table_options.auto_page_scroll = false;   
	}
	this.on_view_form_created = on_view_form_created;
}

task.events.events20 = new Events20();

function Events28() { // video_mana.sample_queries.removed_most_trended_videos 

	function on_view_form_created(item) {
		item.paginate = false;
		item.view_form.find("#edit-btn").hide();
		item.view_form.find("#delete-btn").hide();
		item.view_form.find("#new-btn").hide();
	}
	
	function on_after_open(item) {
		item.server('get_records', function(records) {
			for(var i=0;i<records.length;i++){
				item.append();
				item.id.value=i;
				item.title.value=records[i][0];
				item.total_views.value=records[i][1];
				item.post();
			}
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_open = on_after_open;
}

task.events.events28 = new Events28();

function Events29() { // video_mana.sample_queries.indian_videos_trended_after_yr 

	function on_view_form_created(item) {
		item.paginate = false;
		item.view_form.find("#edit-btn").hide();
		item.view_form.find("#delete-btn").hide();
		item.view_form.find("#new-btn").hide();
	}
	
	function on_after_open(item) {
		item.server('get_records', function(records) {
			for(var i=0;i<records.length;i++){
				item.append();
				item.id.value=i;
				item.title.value=records[i][0];
				item.days_after.value=records[i][1];
				item.post();
			}
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_open = on_after_open;
}

task.events.events29 = new Events29();

function Events30() { // video_mana.sample_queries.monetized_most_liked_comedy_vidoes 

	function on_view_form_created(item) {
		item.paginate = false;
		item.view_form.find("#edit-btn").hide();
		item.view_form.find("#delete-btn").hide();
		item.view_form.find("#new-btn").hide();
	}
	
	function on_after_open(item) {
		item.server('get_records', function(records) {
			for(var i=0;i<records.length;i++){
				item.append();
				item.id.value=i;
				item.title.value=records[i][0];
				item.total_likes.value=records[i][1];
				item.post();
			}
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_open = on_after_open;
}

task.events.events30 = new Events30();

function Events31() { // video_mana.sample_queries.most_tagged_playlist_video 

	function on_view_form_created(item) {
		item.paginate = false;
		item.view_form.find("#edit-btn").hide();
		item.view_form.find("#delete-btn").hide();
		item.view_form.find("#new-btn").hide();
	}
	
	function on_after_open(item) {
		item.server('get_records', function(records) {
			for(var i=0;i<records.length;i++){
				item.append();
				item.id.value=i;
				item.video_title.value=records[i][0];
				item.tags_count.value=records[i][1];
				item.post();
			}
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_open = on_after_open;
}

task.events.events31 = new Events31();

function Events32() { // video_mana.sample_queries.video_highest_comments 

	function on_view_form_created(item) {
		item.paginate = false;
		item.view_form.find("#edit-btn").hide();
		item.view_form.find("#delete-btn").hide();
		item.view_form.find("#new-btn").hide();
	}
	
	function on_after_open(item) {
		item.server('get_records', function(records) {
			for(var i=0;i<records.length;i++){
				item.append();
				item.id.value=i;
				item.uploader.value=records[i][0];
				item.title.value=records[i][1];
				item.total_comments.value=records[i][2];
				item.post();
			}
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_open = on_after_open;
}

task.events.events32 = new Events32();

function Events33() { // video_mana.sample_queries.most_trended_video_per_channel 

	function on_view_form_created(item) {
		item.paginate = false;
		item.view_form.find("#edit-btn").hide();
		item.view_form.find("#delete-btn").hide();
		item.view_form.find("#new-btn").hide();
	}
	
	function on_after_open(item) {
		item.server('get_records', function(records) {
			for(var i=0;i<records.length;i++){
				item.append();
				item.id.value=i;
				item.channel.value=records[i][0];
				item.video.value=records[i][1];
				item.trend_days.value=records[i][2];
				item.post();
			}
		});
	}
	this.on_view_form_created = on_view_form_created;
	this.on_after_open = on_after_open;
}

task.events.events33 = new Events33();

})(jQuery, task)